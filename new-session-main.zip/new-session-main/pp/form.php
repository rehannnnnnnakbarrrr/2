<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">  
    <title>. Login .</title>
    <style>
        marquee{
            color: #554994;
        }
    </style>
  
</head>
<body>
    <div style="padding: 50px;">
    <form action="session.php" method="post">
      <marquee behavior="" direction=""><h2>yhhh</h2></marquee>
        <div>
            Username : 
            <br>
            <input type="text" name="username">
        </div>
        <div>  
            Password : 
            <br>
            <input type="password" name="password">
        <br>
        <br>
        <button type="submit" class="btn btn-primary">Login</button>
        
    </form>
    </div>
</body>
</html>